import { Commonpostsignongatewayservice } from './../../../providers/commonpostsignongatewayservice/commonpostsignongatewayservice';
import { HttpErrorResponse } from '@angular/common/http';
import { LoadingService } from './../../../services/loadingService/loading.service';
import { OtvcRestApiService } from './../../../providers/otvcservice/otvcRESTApiService';
import { OtvcSetupValidator } from '../otvcValidatorService/OtvcSetupValidator';
import { FormGroup, FormBuilder } from '@angular/forms';
import { PopupService } from '../../../services/popupService/popupService';
import { Component } from '@angular/core';
import { IonicPage, NavController, App, NavParams, ModalController } from 'ionic-angular';
//import { AnonymousSubject } from 'rxjs';
//import { OtvcValidatorService } from '../../otvcValidatorService/otvcValidatorService';
import { AppErrorHandler } from '../../../services/errorhandler/AppErrorHandler';
//import { BaseTxnPage } from '../../basetxn/basetxn';
import { BasePage } from '../../base/base';
//import { CachedService }from '../../../services/cachedService/cachedService';
import { SessionStorageService } from '../../../services/StorageService/SessionStorageService';
import { RootService } from '../../../services/rootService/root.service';
import { isUndefined, isDefined } from 'ionic-angular/util/util';
import { ErrorEventHandlerService } from '../../../services/errorEventHandlerService/ErrorEventHandlerService';
import { Location } from '@angular/common';
import { CookieService } from 'ngx-cookie-service';
import { StateTransitionService } from '../../../services/stateTransition/state.transition.service';
import { PageInitService } from '../../../services/pageInitService/pageInitService';
import { LocalStorageService } from '../../../services/StorageService/LocalStorageService';
import { Session } from 'selenium-webdriver';


@IonicPage({ name: 'OtvcSetup', segment: 'otvcSetup' })
@Component({
  selector: 'page-otvcSetup',
  templateUrl: 'otvcSetup.html',
  providers: [AppErrorHandler]
})
export class OtvcSetup extends BasePage {

  isSubmit: boolean;
  pageState: any = {};
  pageContent: any = {};
  completed: boolean;
  modetype: string;
  errorModel: object = {};
  tooltipModal: any;
  skip: string;
  formError: any = {};
  header: string;
  isFormSubmit: boolean;
  lang: string;
  lob: string;
  isWrapper: boolean;
  isIos: boolean;
  headerObj: any;
  footerObj: any;
  PageContentResp: any;
  isDataAvailable: boolean = false;
  hasUnexpectedException: boolean = false;
  unexpectedException: string;
  cachedData: object;
  select: number;
  otvcSetupForm: FormGroup;
  focus: string = "";
  hasError: boolean;
  config = require('../../../providers/commonpostsignongatewayservice/gateway-config.json');
  stateConfig = require('../../../services/stateTransition/state.config.json');
  newdata: any;
  temp: any;
  OtvcDetail: any;
  nonMigrated: boolean;



  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    private app: App,
    public modalCtrl: ModalController,
    public cookieService: CookieService,
    public rootService: RootService,
    //public cachedService: CachedService,
    public loadingService: LoadingService,
    public popupService: PopupService,
    public errorHandler: AppErrorHandler,
    public stateTransitionService: StateTransitionService,
    public location: Location,
    public pageInitService: PageInitService,
    public errorEventHandler: ErrorEventHandlerService,
    private formBuilder: FormBuilder,
    public commonpostsignongatewayservice: Commonpostsignongatewayservice,
    public otvcRestApiService: OtvcRestApiService
  ) {

    super(navCtrl, location, errorEventHandler, errorHandler, stateTransitionService, pageInitService);
    let root: any = RootService.getRoot();
    if (isUndefined(root)) {
      /*  this.lang = (this.navParams.get('lang') ? this.navParams.get('lang') : (this.cookieService.get('MBI_LANG') ? this.cookieService.get('MBI_LANG') : 'en'));
       this.lob = (this.navParams.get('lob') ? this.navParams.get('lob') : (this.cookieService.get('MBI_LOB') ? this.cookieService.get('MBI_LOB') : 'ie'));
       let root = { 'lob': this.lob, 'lang': this.lang };
       RootService.setRoot(root); */
      root = SessionStorageService.getData("root");
    } //else {
    this.lob = root.lob;
    this.lang = root.lang;
    // }

    this.headerObj = {
      "mode": 'SignOn', "showlogo": false, "hideBackButton": true,
      'lob': this.lob, 'lang': this.lang
    };

    this.footerObj = { "type": 'SignOn', 'lob': this.lob, 'lang': this.lang };


  }

  ionViewDidLoad() {
    this.otvcSetupForm = OtvcSetupValidator.createForm(this.otvcSetupForm, this.formBuilder);
  }
  backClick() {
    this.location.back();
  }

  setPageState(data) {

    this.pageContent = data.PageContentResp.Contents;
    this.skip = data.RetrieveOtvcResp.Skip;
    SessionStorageService.clearData('userSigningOn');

    this.isWrapper = RootService.getWrapperObj("isWrapperApp");
    this.setRoot();

    this.headerObj.headerContent = this.pageContent.text.pageHeader;
    this.footerObj.content = this.pageContent;
    this.isDataAvailable = true;
    this.hasUnexpectedException = this.navParams.get('unexpectedException');
    if (this.hasUnexpectedException) {
      this.unexpectedException = this.pageContent.error.unexpectedException;
    }
    this.temp = {};
    // let otvcDetails = data.otvcDetails;
    // if (isDefined(otvcDetails.OtvcDetail)) {
    //   this.OtvcDetail = otvcDetails.OtvcDetail;
    //   this.pageState.alwaysOtvc = otvcDetails.OtvcDetail.AlwaysOtvc;
    //   var contacts = otvcDetails.OtvcDetail.Contact;
    //   contacts.forEach(obj => {
    //     if (obj.Method != 'MOBILE_PHONE_TEXT') {
    //       this.temp[obj.Method] = this.pageState[obj.Method] = obj.Method != 'EMAIL' ? this.formatPhone(obj.Value) : obj.Value;
    //     }
    //   })
    //   this.checkPreviousValue();
    //   this.temp.alwaysOtvc = otvcDetails.OtvcDetail.AlwaysOtvc;
    // } else {
    //   // if ($scope.modetype == 'txn') {
    //   this.nonMigrated = true;
    //   // }
    // }
  }
  setRoot() {
    let root: any = RootService.getRoot();
    if (isUndefined(root)) {
      root = SessionStorageService.getData("root");
    }
    this.lang = root.lob;
    this.lob = root.lang;

  }
  createRequest() {
    RootService.setPageName("OtvcSetup");
    return { "RetrieveOtvcReq": {}, "PageContentReq": { "PageName": "Security" } }
  }

  isNullOrEmpty(value) {

    if (typeof value == "undefined") {
      return true;
    }

    if (typeof value == "object") {
      return !value;
    }

    if (typeof value == "string" && value != "") {
      return false;
    }

    return true;
  }

  next(value: any) {

    OtvcSetupValidator.setValidators(this.otvcSetupForm, this.formBuilder);
    OtvcSetupValidator.setValue(this.otvcSetupForm);

    if (this.otvcSetupForm.valid) {

      // prepare OtvcDetail
      let otvcContacts = [];
      if (!this.isNullOrEmpty(this.pageState.mobilePhone)) {
        otvcContacts.push({ Method: "MOBILE_PHONE", Value: this.pageState.mobilePhone.replace(/[^0-9]/g, '') });
      }

      if (!this.isNullOrEmpty(this.pageState.homePhone)) {
        otvcContacts.push({ Method: "HOME_PHONE", Value: this.pageState.homePhone.replace(/[^0-9]/g, '') });
      }

      if (!this.isNullOrEmpty(this.pageState.businessPhone)) {
        otvcContacts.push({ Method: "BUSINESS_PHONE", Value: this.pageState.businessPhone.replace(/[^0-9]/g, '') });
      }

      if (!this.isNullOrEmpty(this.pageState.email)) {
        otvcContacts.push({ Method: "EMAIL", Value: this.pageState.email });
      }

      var request: any =
      {
        "OtvcContact": otvcContacts
      };
      if (this.pageState.alwaysOtvc) {
        request.alwaysOtvc = this.pageState.alwaysOtvc;
      }

      //submit Otvc
      this.submitOtvc(request);

      // add to cache
      SessionStorageService.setData('otvcSetupCache', request);

      // navigate
      SessionStorageService.setData('userSignedOn', true);

    } else {
      //show validations
      this.formError = OtvcSetupValidator.resolveValidationError(this.otvcSetupForm, this.pageContent.error);
      this.focus = "error";
      console.log('Form Error --- ' + JSON.stringify(this.formError));
      if (this.hasError) {
        super.clearError();
      }
    }
  }

  // submitFailure(failureResult) {
  //   debugger;
  //   let errorObj = JSON.parse(failureResult.error);
  //   let result = super.handleError(failureResult);
  // }
  /*  submitOtvc(){
    
   let pageName = "OtvcVerify";
   RootService.setPageName(pageName);
   let configObj = this.config.pages[RootService.getPageName()];
   let reqresp = {};
   this.loadingService.present();
   
  
   
   
  // "response": result.ValidateOtvcDetailRes  
 
   this.commonpostsignongatewayservice.init(configObj.request, configObj.url).subscribe(
     (data: any) => {
         if (data) {
           reqresp = { "req": configObj.pageDataObj, "resp": data };
           RootService.setPageObj(RootService.getPageName(), reqresp);
         }
       },
       (err: HttpErrorResponse) => {
         this.loadingService.dismiss();
         this.handleError(err);
       });
 
   }  */

  submitOtvc(req) {
    var self = this;
    this.loadingService.present();
    this.transactionValidate(req).subscribe(
      (data: any) => {
        //success callback
        var otvcsetupCache = SessionStorageService.getData('otvcsetupCache');
        if (!self.isNullOrEmpty(otvcsetupCache)) {
          otvcsetupCache.SetData('otvcData', data.data);
        }
        self.transactionSetUserLogIn();

        var otvcsetupCache = SessionStorageService.getData('otvcsetupCache');
        if (!self.isNullOrEmpty(data)) {
          self.completed = true;
          self.loadingService.dismiss();
          self.confirmChange();
          let pageDataObj = {
            "req": req,
            "resp": data
          }
          RootService.setPageName("OtvcVerify");
          SessionStorageService.setData('userSigningOn', true);
          RootService.setPageObj(RootService.getPageName(), pageDataObj);
          RootService.setPreTxnContPage(true);
          return self.navCtrl.push(RootService.getPageName(), { "lob": self.lob, "lang": self.lang }, { animate: false });
        } else {
          //var nextState = (self.modetype == 'txn') ? 'txn.OTVC' : 'preTxn.OTVC';
          /*  if (self.modetype != 'txn' && !self.isNullOrEmpty(otvcsetupCache)) {
             otvcsetupCache.setData('previous', 'otvcsetup');
           } */
          // else {
          /*  if (self.nonMigrated) {
             var OtvcDetail = { "Contact": req.OtvcContact, AlwaysOtvc: req.AlwaysOtvc }
             var dat = {
               PageContentResp: self.PageContentResp,
               RetrieveOtvcResp: { OtvcDetail }
             };
             if (!self.isNullOrEmpty(otvcsetupCache)) {
               otvcsetupCache.setData('previousData', dat);
             }
           } */
        }
      },
      (err: HttpErrorResponse) => {
        //error callback
        var otvcCache = SessionStorageService.getData('otvcsetupCache');
        if (otvcCache) {
          otvcCache.put('errorData', err.error);
        }
        this.hasError = true;
        super.handleError(err);
        this.loadingService.dismiss();

        // _nextState = 'preTxn.signOn';
      }
    );
    // this.gatewayValidate(req).then(
    //   function (result: any) {
    //     var otvcsetupCache = SessionStorageService.getData('otvcsetupCache');
    //     if (!self.isNullOrEmpty(result)) {
    //       self.completed = true;
    //       self.loadingService.dismiss();
    //       self.confirmChange();
    //       let pageDataObj = {
    //         "req": req,
    //         "resp": result
    //       }
    //       RootService.setPageName("OtvcVerify");       
    //       SessionStorageService.setData('userSigningOn', true);
    //       RootService.setPageObj(RootService.getPageName(), pageDataObj);
    //      // this.location.back();
    //       return self.navCtrl.push(RootService.getPageName(), { "lob": self.lob, "lang": self.lang }, { animate: false });
    //     } else {
    //       var nextState = (self.modetype == 'txn') ? 'txn.OTVC' : 'preTxn.OTVC';
    //       if (self.modetype != 'txn' && !self.isNullOrEmpty(otvcsetupCache)) {
    //         otvcsetupCache.setData('previous', 'otvcsetup');
    //       }
    //       // else {
    //       if (self.nonMigrated) {
    //         var OtvcDetail = { "Contact": req.OtvcContact, AlwaysOtvc: req.AlwaysOtvc }
    //         var data = {
    //           PageContentResp: self.PageContentResp,
    //           RetrieveOtvcResp: { OtvcDetail }
    //         };
    //         if (!self.isNullOrEmpty(otvcsetupCache)) {
    //           otvcsetupCache.setData('previousData', data);
    //         }
    //       }
    //       // }
    //       self.loadingService.dismiss();
    //       return self.navCtrl.push(nextState, { "lob": self.lob, "lang": self.lang }, { animate: false });
    //     }
    //   }, this.submitFailure);
  }

  /* submitOtvc(req){
    console.log("II anjjsh d");
    SessionStorageService.setData('userSigningOn', true);
    RootService.setPageName("OtvcVerify");
    this.navCtrl.push("OtvcVerify", { "lob": this.lob, "lang": this.lang }, {animate: false});

  } */

  // cancel(){
  //     var _nextState = 'preTxn.signOn';
  //     var temp_stateParams = {
  //         lang: this.lang,
  //         lob: this.lob
  //     };
  //     this.navCtrl.push(_nextState, temp_stateParams);
  // }


  resetFormError() {
    let controlName = this.otvcSetupForm; // If no parameter passed, whole Form will be reseted.
    if (arguments.length > 0) { // If any parameter passed, that particular controlName will be reseted.
      controlName = arguments[0];
      this.formError[arguments[0]] = OtvcSetupValidator.resetErrorMessage(controlName);
    } else {
      this.formError = OtvcSetupValidator.resetErrorMessage(controlName);
    }
  }


  ///     
  /* req = {
     "PageContentReq": { "PageName": "Security" },
     "RetrieveOtvcReq": {}
 }*/

  /* let APIServices = this.config.APIServices;
      let response = {};
      this.loadingService.present();
      this.commonpostsignongatewayservice.init(request,APIServices["otvcInit"].url).subscribe((data: any) => {
				if (data) {
          this.zeroOrders = data.SearchInfo.TotalNumberOfResult == 0;
          response = { "FilterType": this.selectedFilter, "Data": data };
          if (!this.zeroOrders) {
            this.viewCtrl.dismiss(response);
          }
				} else {
					
				}
				this.loadingService.dismiss();
			},
				(err: HttpErrorResponse) => {
					this.hasError = true;
					super.handleError(err);
					this.loadingService.dismiss();
				});   
    }

    this.otvcGatewayService.init().then(
  }
     */

  /* 
    ionViewDidLoad() {
       this.lang = this.rootService.getLang();
       this.lob = this.rootService.getLOB(); 
    }*/



  /*setPageState(data) {
    SessionStorageService.clearData('userSigningOn');
    console.log(JSON.stringify(data));
  }*/
  // continue() {
  //   SessionStorageService.setData('userSignedOn', true);
  //   RootService.setPageName("OtvcVerify");
  //   this.navCtrl.push("OtvcVerify", { "lob": this.lob, "lang": this.lang }, { animate: false });
  // }


  setInitData(data) {
    this.modetype = 'preTxn';
    if (isDefined(data)) {
      this.skip = data.RetrieveOtvcResp.Skip;
      /*  this.otvcPageState(data.RetrieveOtvcResp, data.PageContentResp.Contents);
       if (isUndefined(otvcsetupCache.get('confirmData'))) { */
      this.confirmChange();
      // }
    }
  }

  handleNextPage(pageName) {
    if (pageName === 'BROADCAST') {
      SessionStorageService.setData('userSigningOn', true);
      RootService.setPageName("Broadcast");
      this.navCtrl.push("Broadcast", { "lob": this.lob, "lang": this.lang }, { animate: false });
    }
  }

  skipOtvc() {
    var self = this;
    this.transactionSkip({}).subscribe(
      (data: any) => {
        this.loadingService.dismiss();
        console.log('Success callback of OTVC verify');
        console.log('result=');
        console.log(JSON.stringify(data));
        self.handleNextPage(data.NextPage);
      }, (err: HttpErrorResponse) => {
        let errResult = super.handleError(err);
        console.log('Error callback of touch id settings init. failureResult=');
        console.log(JSON.stringify(err));
        self.loadingService.dismiss();
      }
    );
    this.loadingService.present();
  }


  confirmChange() {
    this.loadingService.dismiss();
    let alertContent = {
      title: "",
      subTitletitle: "",
      message: this.pageContent.text.completed,
      buttons: [{ text: this.pageContent.text.okButton }],
      onPresent: () => {
        /*  var otvcsetupCache = SessionStorageService.getData('otvcsetupCache');
         otvcsetupCache.remove('confirmData'); */
        SessionStorageService.clearData('otvcsetupCache');
      }
    };
    //this.popupService.presentAlert(alertContent);
  }


  toViewFormat(modelPhone) {
    modelPhone = modelPhone.replace(/[^0-9]/g, '');
    if (modelPhone) {
      // this.isSubmit = isDefined(this.pageState.email.value)?validateemail(this.pageState.email.value):true;  
      //e.g. 416
      if (modelPhone.length <= 3) {
        return modelPhone;
      }
      //e.g. 416581
      if (modelPhone.length <= 6) {
        let area = modelPhone.substr(0, 3);
        let num1 = modelPhone.substr(3);
        return `${area} ${num1}`;
      }
      //e.g. 14165817080
      let area = modelPhone.substr(0, 3);
      let num1 = modelPhone.substr(3, 3);
      let num2 = modelPhone.substr(6, 4);
      return `(${area}) ${num1}-${num2}`;
    }
    return modelPhone;
  }

  checkPreviousValue() {
    if ((this.isNull(this.pageState.homePhone) != this.temp.homePhone)
      || (this.isNull(this.pageState.mobilePhone) != this.temp.mobilePhone)
      || (this.isNull(this.pageState.businessPhone) != this.temp.businessPhone)
      || (this.isNull(this.pageState.email) != this.temp.email) || (this.pageState.alwaysOtvc != this.temp.alwaysOtvc)) {
      return true;
    } else {
      return false;
    }
  }

  isNull(obj) {
    return (obj == "") ? undefined : obj;
  }

  preventChar(event) {
    const pattern = /[0-9]/;
    let input = String.fromCharCode(event.charCode);
    if (!pattern.test(input)) {
      event.preventDefault();
    }
  }


  validateSubmit() {
    var validPhone = (isDefined(this.pageState.homePhone) || isDefined(this.pageState.mobilePhone) || isDefined(this.pageState.businessPhone));
    if (isDefined(this.pageState.email) && this.pageState.email != "") {
      this.isSubmit = this.validateEmail(this.pageState.email) && validPhone;
    } else {
      this.isSubmit = validPhone;
    }
  }

  validateEmail(email) {
    let passWhitelist = false;
    let INVERSE_WHITELIST = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if (isDefined(email) && email != "") {
      passWhitelist = !(email.match(INVERSE_WHITELIST) === null);
      this.isSubmit = passWhitelist;
      return passWhitelist;
    } else {
      this.isSubmit = (isDefined(this.pageState.homePhone) || isDefined(this.pageState.mobilePhone) || isDefined(this.pageState.businessPhone));
      return this.isSubmit;
    }
  }

  openemailInfo() {
    this.tooltipModal.openModal();
    //to-do: copy deleted
  }

  isUserLogIn() {
    var restoredValue = SessionStorageService.getData('userSignedOn');
    var userSignedOn = restoredValue;
    if (!isDefined(userSignedOn)) {
      userSignedOn = false;
    }
    return userSignedOn;
  }



  cancel() {
    let request = {
      "SavedUserIdsReq": {},
      "PageContentReq": {}
    };
    RootService.omniturePageName("Pre-Sign On>Signoff");
    this.commonpostsignongatewayservice.init(request, this.config.APIServices.signoff.url).subscribe(
      (data: any) => {
        SessionStorageService.setData("userSignedOn", false);
        RootService.setPageName("Home");
        this.app.getRootNav().setRoot("Home", { 'lob': this.lob, 'lang': this.lang });
      },
      (err: HttpErrorResponse) => {
        super.handleError(err);
        SessionStorageService.setData("userSignedOn", false);
        RootService.setPageName("Home");
        this.app.getRootNav().setRoot("Home", { 'lob': this.lob, 'lang': this.lang });
      }
    );
    LocalStorageService.clearAllData();
    SessionStorageService.clearRefreshData();
    SessionStorageService.clearData("touchIdEnabled");
    SessionStorageService.clearData("touchidCache");
    RootService.setHistoryPosition(-1);
    RootService.setHistory([]);
  }


  /*

transactionInit(payload) {
  let endpoint = this.config.appRestBaseUrl + this.config.cibcOtvcSetupConfig.serviceRootURL +
    this.config.cibcOtvcSetupConfig.serviceURLs.initURL;

  return this.otvcRestApiService.init(endpoint, payload);
}*/
  transactionValidate(obj) {
    var payload = {
      ValidateOtvcDetailReq: obj,
      PageContentReq: { "PageName": "IdentityVerification" }
    };

    return this.otvcRestApiService.validate(payload);
  }

  transactionSetUserLogIn() {
    if (!this.isUserLogIn()) {
      SessionStorageService.setData('userSignedOn', true);
    }
  }

  transactionSkip(payload) {
    return this.otvcRestApiService.skip(payload);
  }

  /*Gateway service methods*/
  //gatewayInit(mode) {
  // CibcStorage.setObject(
  //     CibcStorage.sessionStorage,
  //     CibcStorage.cookieStorage,
  //     'userSignedOn', true);
  //return new Promise((resolve, reject) => {
  // let req = {
  //   "PageContentReq": { "PageName": "Security" },
  //   "RetrieveOtvcReq": {}
  // }
  // this.transactionInit(req).subscribe(function (result) {
  //   var otvcsetupCache = SessionStorageService.getData('otvcsetupCache');
  //   otvcsetupCache.put('initData', result.data);
  //   otvcsetupCache.put('mode', mode);
  //   this.canProceed = true;
  //   if (mode == 'preTxn') {
  //     this.nextState = 'preTxn.OTVCSETUP';
  //   } else {
  //     if (mode == 'DEFAULT') {
  //       otvcsetupCache.put('confirmData', true);
  //     }
  //     this.nextState = 'txn.OTVCSETUP'
  //   }
  //   resolve(result);
  // }, function (result) {
  //   reject(result);
  // });
  //});
  // }

  /*  gatewayValidate(req) {
     return new Promise((resolve, reject) => {
       this.transactionValidate(req).subscribe(
         (data: any) => {
           //success callback
           var otvcsetupCache = SessionStorageService.getData('otvcsetupCache');
           if (!this.isNullOrEmpty(otvcsetupCache)) {
             otvcsetupCache.SetData('otvcData', data.data);
           }
           this.transactionSetUserLogIn();
           resolve(data);
         },
         (err: HttpErrorResponse) => {
           //error callback
           var otvcCache = SessionStorageService.getData('otvcsetupCache');
           if (otvcCache) {
             otvcCache.put('errorData', err.error);
           }
           super.handleError(err);
           // _nextState = 'preTxn.signOn';
           reject(err);
         }
       );
     });
   } */
}



