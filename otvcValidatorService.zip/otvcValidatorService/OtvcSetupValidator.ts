import { FormValidatorFactory } from './../../../services/formvalidator/cibc.formvalidator';
import { OtvcErrorMessages } from './OtvcErrorMessages';
import { isDefined } from 'ionic-angular/util/util';
import { FormBuilder } from '@angular/forms';

export class OtvcSetupValidator {

    static createForm(form, fb) {
        form = fb.group({
            'mobilePhone': [""],
            'HOME_PHONE': [""],
            'BUSINESS_PHONE': [""],
            'EMAIL': [""],
            'alwaysOtvc': [""]
        });

        return form;
    }

    static setValidators(form, formBuilder) {
        form.controls['mobilePhone'].setValidators([FormValidatorFactory.createPhoneNumberValidator(OtvcErrorMessages.MSG_INVALID_PHONE)]);
        form.controls['HOME_PHONE'].setValidators([FormValidatorFactory.createPhoneNumberValidator(OtvcErrorMessages.MSG_INVALID_PHONE)]);
        form.controls['BUSINESS_PHONE'].setValidators([FormValidatorFactory.createPhoneNumberValidator(OtvcErrorMessages.MSG_INVALID_PHONE)]);
        form.controls['EMAIL'].setValidators([FormValidatorFactory.createPhoneNumberValidator(OtvcErrorMessages.MSG_INVALID_PHONE)]);
        form.controls['alwaysOtvc'].setValidators([FormValidatorFactory.createPhoneNumberValidator(OtvcErrorMessages.MSG_16_ALWAYS_OTVC)]);

    }

    static setValue(form) {
        form.setValue({
            'mobilePhone': form.value.mobilePhone || "",
            'HOME_PHONE': form.value.HOME_PHONE || "",
            'BUSINESS_PHONE': form.value.BUSINESS_PHONE || "",
            'EMAIL': form.value.EMAIL || "",
            'alwaysOtvc': form.value.alwaysOtvc || ""
        });
    }

    static resolveValidationError(form, errorContent) {
        let messges = [];
        messges.push({
            controlName: 'mobilePhone',
            code: form.controls['mobilePhone'].errors
        });
        messges.push({
            controlName: 'HOME_PHONE',
            code: form.controls['HOME_PHONE'].errors
        });
        messges.push({
            controlName: 'BUSINESS_PHONE',
            code: form.controls['BUSINESS_PHONE'].errors
        });
        messges.push({
            controlName: 'alwaysOtvc',
            code: form.controls['alwaysOtvc'].errors
        });

        return this.setErrorMessage(messges, errorContent);
    }

    static setErrorMessage(results, errorContent) {
        let error = {};
        results.forEach(result => {
            if (result.code !== null) {
                if (isDefined(result.code.errorCode)) {
                    error[result.controlName] = errorContent[result.code.errorCode];
                }
                console.log(JSON.stringify(result));
            }
        });
        return error;
    }

    static processRestFormErrors(formError) {
        let error = {};
        if (formError.error.Category === 'HOME_PHONE') {
            error['HOME_PHONE'] = formError.error.Errors[0].ErrorMessage
        }

        if (formError.error.Category === 'mobilePhone') {
            error['mobilePhone'] = formError.error.Errors[0].ErrorMessage
        }

        if (formError.error.Category === 'BUSINESS_PHONE') {
            error['BUSINESS_PHONEs'] = formError.error.Errors[0].ErrorMessage
        }
        if (formError.error.Category === 'alwaysOtvc') {
            error['alwaysOtvc'] = formError.error.Errors[0].ErrorMessage
        }
        return error;
    }

    static resetErrorMessage(controlName) {
        let messges = [];
        let error = {};
        if (typeof controlName === "string") {
            error[controlName] = undefined;
            return error[controlName];
        } else {
            messges.push({
                controlName: 'BUSINESS_PHONE',
                code: controlName.controls['BUSINESS_PHONE'].errors
            });
            messges.push({
                controlName: 'HOME_PHONE',
                code: controlName.controls['HOME_PHONE'].errors
            });
            messges.push({
                controlName: 'mobilePhone',
                code: controlName.controls['mobilePhone'].errors
            });
            messges.push({
                controlName: 'alwaysOtvc',
                code: controlName.controls['alwaysOtvc'].errors
            });
            messges.forEach(result => {
                error[result.controlName] = undefined;
            });
            return error;
        }
    }
}