export class OtvcErrorMessages{
    static MSG_INVALID_PHONE_FORMAT : 'MSGOTV008'; 
    static MSG_INVALID_PHONE : 'MSGOTV009'; 
    static MSG_INPUT_SELECTION : 'MSGOTV016'; 
    static MSG_NO_RESULT : 'MSGGLB076';  
    static MSG_16_ALWAYS_OTVC : 'MSGGLB076';
}