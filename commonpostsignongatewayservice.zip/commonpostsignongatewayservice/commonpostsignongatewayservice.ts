import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';

@Injectable()
export class Commonpostsignongatewayservice {
  data: any;
  constructor(public http: HttpClient) {

  }

  success(data: any) {
    let temp = JSON.parse(data);
    return temp;
  }
  /* All Init calls made from the Side Menu */

  init(request, url): any {
    if (this.data) {
      return Observable.of(this.data);
    } else if (request == null) {
      return this.http.get(url,{responseType: 'text'}).map(this.success, this);
    } else {
      return this.http.post(url, request,{responseType: 'text'}).map(this.success, this);
    }
  }

  initMultiple(payloads): any { // [{url: A, request: B}, ...]
    if (this.data) {
      return Observable.of(this.data);
    } else {
      //return this.http.get('assets/data/myaccount.json').map(this.success, this);
      let requestList = [];
      for (var i = 0; i < payloads.length; i++) {
        if (payloads[i].request == undefined || payloads[i].request == null) {
          requestList.push(this.http.get(payloads[i].url, {responseType: 'text'}).map(this.success, this));
        } else {
          requestList.push(this.http.post(payloads[i].url, payloads[i].request, {responseType: 'text'}).map(this.success, this));
        }
      }
      return Observable.forkJoin(requestList);
    }
  }
}
