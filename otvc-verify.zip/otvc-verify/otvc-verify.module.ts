import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OtvcVerify } from './otvc-verify';
import { ComponentsModule } from '../../../components/components.module';

@NgModule({
  declarations: [
    OtvcVerify,
  ],
  imports: [ComponentsModule,
    IonicPageModule.forChild(OtvcVerify),
  ],
  exports: [
    OtvcVerify
  ],
})
export class OtvcVerifyPageModule { }
