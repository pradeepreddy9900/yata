import { CommonGatewayService } from './../../../providers/commongatewayservice/commongatewayservice';
import { LoadingService } from './../../../services/loadingService/loading.service';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { Commonpostsignongatewayservice } from './../../../providers/commonpostsignongatewayservice/commonpostsignongatewayservice';
import { OtvcRestApiService } from './../../../providers/otvcservice/otvcRESTApiService';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { PopupService } from '../../../services/popupService/popupService';
//import { AnonymousSubject } from 'rxjs';
//import { OtvcValidatorService } from '../../otvcValidatorService/otvcValidatorService';
import { AppErrorHandler } from '../../../services/errorhandler/AppErrorHandler';
//import { BaseTxnPage } from '../../basetxn/basetxn';
import { BasePage } from '../../base/base';
//import { CachedService }from '../../../services/cachedService/cachedService';
import { SessionStorageService } from '../../../services/StorageService/SessionStorageService';
import { RootService } from '../../../services/rootService/root.service';
import { isUndefined, isDefined } from 'ionic-angular/util/util';
import { ErrorEventHandlerService } from '../../../services/errorEventHandlerService/ErrorEventHandlerService';
import { Location } from '@angular/common';
import { CookieService } from 'ngx-cookie-service';
import { StateTransitionService } from '../../../services/stateTransition/state.transition.service';
import { PageInitService } from '../../../services/pageInitService/pageInitService';
import { OtvcSetupValidator } from '../otvcValidatorService/OtvcSetupValidator';
import { FormGroup, FormBuilder } from '@angular/forms';
/**
 * Generated class for the OtvcVerify page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({ name: 'OtvcVerify', segment: 'otvcVerify' })
@Component({
  selector: 'page-otvc-verify',
  templateUrl: 'otvc-verify.html',
})
export class OtvcVerify extends BasePage {

  isSubmit: boolean;
  pageState: any = {};
  pageContent: any = {};
  completed: boolean;
  modetype: string;
  errorModel: any = {};
  tooltipModal: any;
  skip: any;
  formError: any = {};
  header: string;
  isFormSubmit: boolean;
  lang: string;
  lob: string;
  isWrapper: boolean;
  isIos: boolean;
  headerObj: any;
  footerObj: any;
  PageContentResp: any;
  isDataAvailable: boolean = false;
  hasUnexpectedException: boolean = false;
  unexpectedException: string;
  data: object;
  select: number;
  otvcVerifyForm: FormGroup;
  focus: string = "";
  hasError: boolean;
  content: any;
  otvcDetail: any;
  showMenu: boolean;
  isSend: boolean;
  model: any = {};
  isResendEnable: boolean;
  canProceed: boolean;
  nextState: string;
  PageObj: any;
  showSend: boolean;


  config = require('../../../providers/commonpostsignongatewayservice/gateway-config.json');
  stateConfig = require('../../../services/stateTransition/state.config.json');


  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public modalCtrl: ModalController,
    public cookieService: CookieService,
    public rootService: RootService,
    //public cachedService: CachedService,
    public loadingService: LoadingService,
    public popupService: PopupService,
    public errorHandler: AppErrorHandler,
    public stateTransitionService: StateTransitionService,
    public location: Location,
    public pageInitService: PageInitService,
    public errorEventHandler: ErrorEventHandlerService,
    private formBuilder: FormBuilder,
    // public commonGatewayService: Commonpostsignongatewayservice,
    public otvcRestApiService: OtvcRestApiService,
    private commongatewayservice: CommonGatewayService
  ) {

    super(navCtrl, location, errorEventHandler, errorHandler, stateTransitionService, pageInitService);


    let root: any = RootService.getRoot();
    if (isUndefined(root)) {
      this.lang = (this.navParams.get('lang') ? this.navParams.get('lang') : 'en');
      this.lob = (this.navParams.get('lob') ? this.navParams.get('lob') : 'ie');
      let root = { 'lob': this.lob, 'lang': this.lang };
      RootService.setRoot(root);
    } else {
      this.lob = root.lob;
      this.lang = root.lang;
    }
    RootService.omniturePageName("Sign On-Personal Verification Questions");
    this.headerObj = {
      "mode": 'SignOn',
      "showlogo": false,
      "hideBackButton": false,
      'lob': this.lob,
      'lang': this.lang
    };
    RootService.setPageName("OtvcVerify");
    this.PageObj = RootService.getPageObj(RootService.getPageName());
    this.footerObj = { "type": 'preSignOn', 'lob': this.lob, 'lang': this.lang };
    this.otvcVerifyForm = OtvcSetupValidator.createForm(this.otvcVerifyForm, this.formBuilder);
  }
  // ionViewDidLoad() {
  //   console.log('ionViewDidLoad OtvcVerify');
  //   this.setPageState(this.PageObj.resp);
  // }

  createRequest() {
    RootService.setPageName("OtvcVerify");
    return {
      "PageContentReq": { "PageName": "IdentityVerification" },
      "RetrieveOtvcReq": {}
    }
  }
  backClick() {
    this.location.back();
  }

  getModeContent(mode) {
    return this.pageContent.text[mode];
  }

  clearCode() {
    this.model.verifyCode = '';
    // if (!this.isNullOrEmpty(this.errorModel)&& (!this.isNullOrEmpty(this.errorModel.model.verifyCode))) {
    //   this.errorModel.model.verifyCode.$error = {};
    // }
  }

  setPageState(data) {
    this.setInitData();

    this.pageContent = data.resp.PageContentResp.Contents;
    SessionStorageService.clearData('userSigningOn');
    this.headerObj.headerContent = this.pageContent.text.pageHeader;
    this.isWrapper = RootService.getWrapperObj("isWrapperApp");

    this.footerObj.content = this.pageContent;

    this.hasUnexpectedException = this.navParams.get('unexpectedException');
    if (this.hasUnexpectedException) {
      this.unexpectedException = this.pageContent.error.unexpectedException;
    }
    this.isDataAvailable = true;

    /*  var otvcdata = SessionStorageService.getData('data');
      this.modetype = this.isUserLogIn() ? 'txn' : 'preTxn';
      this.content = otvcdata.PageContentResp.Contents; 
      this.header = this.content.text.pageHeader;*/
    if (!this.isNullOrEmpty(data.resp.RetrieveOtvcResp)) {
      this.otvcDetail = data.resp.RetrieveOtvcResp.OtvcDetail;
    } else {
      this.otvcDetail = data.resp.ValidateOtvcDetailRes.OtvcDetail;
    }


    /*  if (!this.isNullOrEmpty(SessionStorageService.getData('pageFlow'))) {
       if (SessionStorageService.getData('pageFlow') == 'TXN') {
         this.showMenu = true;
       } else {
         this.showMenu = false;
       } 
     } */


    /* if(isDefined(data.RetrieveOtvcResp)){
      this.otvcDetail = data.RetrieveOtvcResp.OtvcDetail;
    }else {
      this.otvcDetail = data.ValidateOtvcDetailRes.OtvcDetail;
    } */
    if (!this.isNullOrEmpty(this.otvcDetail.LastUsed)) {
      this.isSend = false;
      this.model.otvcType = this.otvcDetail.LastUsed;
    }
    // only one contact which is black listed, then show error and disable the dropdown.
    if (!this.isNullOrEmpty(this.otvcDetail.Contact)) {
      if (this.otvcDetail.Contact.length == 1) {
        if (this.otvcDetail.Contact[0].BlackListed) {
          this.otvcDetail.Contact[0].BlackListed = false;
          this.model.otvcType = this.otvcDetail.Contact[0].Method;
          this.isResendEnable = true;
          this.isSend = true;
          //to-do: add this method
          //displayError("MSGOTV003");
        }
      }
    }
  }

  handleSelection(obj) {
    this.isSend = (this.model.otvcType == -1);
    // var safeErrorModel = new SafeObjectService.SafeObject(this.errorModel);
    // handleClearErrorModel(safeErrorModel.get('model').getUnsafe('$error'));
  }

  handleSend() {
    this.otvcRestApiService.OTVCSend({ "ContactMethod": this.model.otvcType }).subscribe(
      (result: any) => {
        this.loadingService.dismiss();
        // @ifdef DEBUG 
        console.log('Success callback of OTVC Send');
        console.log('result=');
        console.log(JSON.stringify(result));
        // @endif
        this.showSend = false;
        this.isResendEnable = true;
        this.sentSelected();
      },
      (err: HttpErrorResponse) => {
        this.hasError = true;
        super.handleError(err);
        this.loadingService.dismiss();
      }
    );
    this.loadingService.present();
  }

  sentSelected() {
    var self = this;
    setTimeout(function () {
      self.isResendEnable = false;
      self.loadingService.dismiss();
    }, 2000);
  }

  /*  goToSignOn() {
     var _nextState = 'preTxn.signOn';
     var temp_stateParams = {
       lang: this.lang,
       lob: this.lob
     };
 
     return this.navCtrl.push(_nextState, temp_stateParams);
   }
 
 
   cancel() {
     this.goToSignOn();
   } */

  next() {
    // //Reset Error model
    // var safeErrorModel = new SafeObjectService.SafeObject(this.errorModel);
    // handleClearErrorModel(safeErrorModel.get('model').getUnsafe('$error'));

    // safeErrorModel = new SafeObjectService.SafeObject(this.pageState);
    // handleClearErrorModel(safeErrorModel.get('pvqAnswer').getUnsafe('$error'));

    this.verify();
  }

  gatewayOtvcVerify(verifyCode) {
    return new Promise((resolve, reject) => {
      this.otvcRestApiService.OTVCVerify(verifyCode).subscribe(
        (result) => {
          //success callback
          SessionStorageService.setData('verifydata', result.data);
          this.canProceed = true;
          //this.nextState = 'MyAccounts';
          resolve(result);
        }),
        (err: HttpErrorResponse) => {
          let et = super.handleError(err);
          SessionStorageService.setData('errorData', err.error);
          reject(err);
        }
    });
  }

  handleNextPage(pageName) {
    if (pageName === 'BROADCAST') {
      SessionStorageService.setData('userSigningOn', true);
      RootService.setPageName("Broadcast");
      this.navCtrl.push("Broadcast", { "lob": this.lob, "lang": this.lang }, { animate: false });
    }
  }

  verify() {
    let self = this;
    this.gatewayOtvcVerify({ Code: this.model.verifyCode }).then(
      (data: any) => {
        self.loadingService.dismiss();
        // @ifdef DEBUG 
        console.log('Success callback of OTVC verify');
        console.log('result=');
        console.log(JSON.stringify(data));
        // @endif
        this.handleNextPage(data.NextPageName);
        return false;
      },
      (err: HttpErrorResponse) => {
        this.hasError = true;
        super.handleError(err);
        this.loadingService.dismiss();
      }
    );
    this.loadingService.present();
  }

  isUserLogIn() {
    var restoredValue = SessionStorageService.getData('userSignedOn');
    var userSignedOn = restoredValue;
    if (!isDefined(userSignedOn)) {
      userSignedOn = false;
    }
    return userSignedOn;
  }

  isNullOrEmpty(value) {

    if (typeof value == "undefined") {
      return true;
    }

    if (typeof value == "object") {
      return !value;
    }

    if (typeof value == "string" && value != "") {
      return false;
    }

    return true;
  }

  chkVerify(obj) {
    if (!this.isNullOrEmpty(obj)) {
      obj = obj.replace(/[^0-9]/g, '');
      if (obj == this.pageContent.text.CIBCphonenumber) {
        this.errorModel = {
          verifyCode: this.pageContent.error["MSGOTV013"]
        };

      } else {
        // if (!this.isNullOrEmpty(this.errorModel)&& (!this.isNullOrEmpty(this.errorModel.model.verifyCode))) {
        //   this.errorModel.model.verifyCode.$error = {};
        // }
      }
      return obj;
    } else {
      return;
    }
  }

  preventChar(event) {
    const pattern = /[0-9]/;
    let input = String.fromCharCode(event.charCode);
    if (!pattern.test(input)) {
      event.preventDefault();
    }
  }

  setInitData() {
    this.showSend = true;
    this.isResendEnable = false;
    this.pageState = {};
    this.isSend = true;
    //this.errorContent ={};

    this.model = {};
    this.model.otvcType = '-1';
    this.model.verifyCode = '';
  }
}
