import { Component, NgZone } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';
import { isUndefined } from 'ionic-angular/util/util';
import { RootService } from '../../services/rootService/root.service';
import { BasePage } from '../base/base';
import { Location } from '@angular/common';
import { AppErrorHandler } from '../../services/errorhandler/AppErrorHandler';
import { ErrorEventHandlerService } from '../../services/errorEventHandlerService/ErrorEventHandlerService';
import { SessionStorageService } from '../../services/StorageService/SessionStorageService';
import { CommonserviceProvider } from '../../providers/commonservice/commonservice';
import { Commonpostsignongatewayservice } from '../../providers/commonpostsignongatewayservice/commonpostsignongatewayservice';
import { HttpErrorResponse } from '@angular/common/http';
import { LoadingService } from '../../services/loadingService/loading.service';
import { StateTransitionService } from './../../services/stateTransition/state.transition.service';
import { PageInitService } from '../../services/pageInitService/pageInitService';
import { CachedService } from '../../services/cachedService/cachedService';
declare var require: any;
@IonicPage({name: 'Broadcast',segment: 'broadcast'})
@Component({
  selector: 'page-broadcast',
  templateUrl: 'broadcast.html',
  providers: [AppErrorHandler]
})
export class Broadcast extends BasePage{
  BroadcastMessageResp: any;
  pageContent: any;
  isDataAvailable: boolean = false;
  lang: string;
  lob: string;
  headerObj:any;
  config = require('../../providers/commonpostsignongatewayservice/gateway-config.json');

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public menu: MenuController,
    public errorHandler: AppErrorHandler,
    public errorEventHandler: ErrorEventHandlerService,
    public commonService: CommonserviceProvider,
    public commonpostsignongatewayservice: Commonpostsignongatewayservice,
    public loadingService: LoadingService,
    public location: Location,
    public stateTransitionService: StateTransitionService,
    public pageInitService: PageInitService,
    public zone: NgZone,
  ) {
    super(navCtrl, location, errorEventHandler, errorHandler, stateTransitionService, pageInitService);
      let root: any = RootService.getRoot();
      if (isUndefined(root)) {
        this.lang = (this.navParams.get('lang') ? this.navParams.get('lang') : 'en');
        this.lob = (this.navParams.get('lob') ? this.navParams.get('lob') : 'ie');
        let root = { 'lob': this.lob, 'lang': this.lang };
        RootService.setRoot(root);
      } else {
        this.lob = root.lob;
        this.lang = root.lang;
        console.log("constructor");
      }
      RootService.omniturePageName("Sign On-Personal Verification Questions");
      this.headerObj = { "mode": 'SignOn', "showlogo": true, "hideBackButton": true, 
    'lob': this.lob, 'lang': this.lang};
  }

  createRequest() {
    RootService.setPageName("Broadcast");
    return { "BroadcastMessageReq": {}, "PageContentReq": { "PageName": "BroadcastMessage" } };
  }

  setPageState(data) {
    SessionStorageService.clearData('userSigningOn');
    this.BroadcastMessageResp = data.BroadcastMessageResp;
    this.pageContent = data.PageContentResp.Contents;
    this.isDataAvailable = true;
    this.headerObj.headerContent = this.pageContent.text.header;
  }

  continue() {
    if (this.BroadcastMessageResp.NextPageName === 'txn.MYACCOUNTS' || 
        this.BroadcastMessageResp.NextPageName === 'txn.MYACCOUNTS_EX_TOUCHID') {
      SessionStorageService.setData('userSignedOn', true);
      let SideMenuReq = {
        "SideMenuReq": {},
        "PageContentReq": { "PageName": "SideMenu" }
      };
      // Also laoding MyAccount Request here for 1st time FRESH login.... 
      // From Side Menu it will be handled by IonViewWillEnter of BaseTxn
      let pageName = "MyAccounts";
      RootService.setPageName(pageName);
      let configObj = this.config.pages[RootService.getPageName()];
      let reqresp = {};
      this.loadingService.present();
      this.commonpostsignongatewayservice.init(configObj.request, configObj.url).subscribe(
        (data: any) => {
            if (data) {
              reqresp = { "req": configObj.request, "resp": data };
              RootService.setPageObj(RootService.getPageName(), reqresp); // Here PageName already set to MyAccounts  
              this.commonService.sideMenu(SideMenuReq).subscribe(
                (data: any) => {
                  RootService.setPageObj("sideMenu", data);
                  RootService.setHistoryPosition(-1);
                  RootService.setHistory([]);
                  this.menu.enable(true);
                  this.navCtrl.setRoot('Txn', { "Lob": this.lob, "Lang": this.lang, "isFirstLoad": true });
                },
                (err: HttpErrorResponse) => {
                  this.loadingService.dismiss();
                  this.handleError(err);
                });
          }
        },
        (err: HttpErrorResponse) => {
          this.loadingService.dismiss();
          this.handleError(err);
        });
    } else if (this.BroadcastMessageResp.NextPageName === 'txn.TOUCHID_SETUP') {
      var touchidCache = SessionStorageService.getData('touchidCache');
      touchidCache.fromSignOn = true;
      SessionStorageService.setData('touchidCache', touchidCache);

      SessionStorageService.setData('userSignedOn', true);
      let SideMenuReq = {
        "SideMenuReq": {},
        "PageContentReq": { "PageName": "SideMenu" }
      };
      this.commonService.sideMenu(SideMenuReq).subscribe(
        (data: any) => {
          RootService.setPageObj("sideMenu", data);
          let pageName = "TouchID";
          let configObj = this.config.pages[pageName];
          let reqresp = {};
          this.commonpostsignongatewayservice.init(configObj.request, configObj.url).subscribe(
            (data: any) => {
              if (data) {
                reqresp = { "req": configObj.request, "resp": data };
                RootService.setPageObj(pageName, reqresp);
                RootService.setPageName(pageName);
                RootService.setHistoryPosition(-1);
                RootService.setHistory([]);
                this.menu.enable(true);
                this.navCtrl.setRoot('Txn', { "Lob": this.lob, "Lang": this.lang, "isFirstLoad": true  });
              } else {
                this.loadingService.dismiss();
              }
            },
            (err: HttpErrorResponse) => {
              this.loadingService.dismiss();
              this.handleError(err);
            }
          )
        },
        (err: HttpErrorResponse) => {
          this.loadingService.dismiss();
          this.handleError(err);
        }
      );
    }
  }
}