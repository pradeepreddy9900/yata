import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Broadcast } from './broadcast';
import { ComponentsModule } from '../../components/components.module';
import { CommonserviceProvider } from '../../providers/commonservice/commonservice';
import { Commonpostsignongatewayservice } from '../../providers/commonpostsignongatewayservice/commonpostsignongatewayservice';

@NgModule({
  declarations: [
    Broadcast,
  ],
  imports: [
    ComponentsModule,
    IonicPageModule.forChild(Broadcast),
  ],
  exports:[
    Broadcast
  ],
  providers: [
    CommonserviceProvider,
    Commonpostsignongatewayservice
  ]
})
export class BroadcastPageModule {}
