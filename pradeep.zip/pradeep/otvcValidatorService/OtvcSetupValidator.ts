import { FormValidatorFactory } from './../../../services/formvalidator/cibc.formvalidator';
import { OtvcErrorMessages } from './OtvcErrorMessages';
import { isDefined } from 'ionic-angular/util/util';

export class OtvcSetupValidator {

    static createForm(form, fb) {
        form = fb.group({
            'MOBILE_PHONE': [""],
            'HOME_PHONE': [""],
            'BUSINESS_PHONE': [""]
        });

        return form;
    }

    static setValidators(form) {
        form.controls['MOBILE_PHONE'].setValidators([FormValidatorFactory.createPhoneNumberValidator(OtvcErrorMessages.MSG_INVALID_PHONE)]);
        form.controls['HOME_PHONE'].setValidators([FormValidatorFactory.createPhoneNumberValidator(OtvcErrorMessages.MSG_INVALID_PHONE)]);
        form.controls['BUSINESS_PHONE'].setValidators([FormValidatorFactory.createPhoneNumberValidator(OtvcErrorMessages.MSG_INVALID_PHONE)]);
    }

    static setValue(form) {
        form.setValue({
            'MOBILE_PHONE': form.value.MOBILE_PHONE || "",
            'HOME_PHONE': form.value.HOME_PHONE || "",
            'BUSINESS_PHONE': form.value.BUSINESS_PHONE || "",
        });
    }

    static resolveValidationError(form, errorContent) {
        let messges = [];
        messges.push({
            controlName: 'MOBILE_PHONE',
            code: form.controls['MOBILE_PHONE'].errors
        });
        messges.push({
            controlName: 'HOME_PHONE',
            code: form.controls['HOME_PHONE'].errors
        });
        messges.push({
            controlName: 'BUSINESS_PHONE',
            code: form.controls['BUSINESS_PHONE'].errors
        });
        return this.setErrorMessage(messges, errorContent);
    }

    static setErrorMessage(results, errorContent) {
        let error = {};
        results.forEach(result => {
            if (result.code !== null) {
                if (isDefined(result.code.errorCode)) {
                    error[result.controlName] = errorContent[result.code.errorCode];
                }
                console.log(JSON.stringify(result));
            }
        });
        return error;
    }

    static processRestFormErrors(formError) {
        let error = {};
        if (formError.error.Category === 'HOME_PHONE') {
            error['HOME_PHONE'] = formError.error.Errors[0].ErrorMessage
        }

        if (formError.error.Category === 'MOBILE_PHONE') {
            error['MOBILE_PHONE'] = formError.error.Errors[0].ErrorMessage
        }

        if (formError.error.Category === 'BUSINESS_PHONE') {
            error['BUSINESS_PHONEs'] = formError.error.Errors[0].ErrorMessage
        }
        return error;
    }

    static resetErrorMessage(controlName) {
        let messges = [];
        let error = {};
        if (typeof controlName === "string") {
            error[controlName] = undefined;
            return error[controlName];
        } else {
            messges.push({
                controlName: 'BUSINESS_PHONE',
                code: controlName.controls['BUSINESS_PHONE'].errors
            });
            messges.push({
                controlName: 'HOME_PHONE',
                code: controlName.controls['HOME_PHONE'].errors
            });
            messges.push({
                controlName: 'MOBILE_PHONE',
                code: controlName.controls['MOBILE_PHONE'].errors
            });
            messges.forEach(result => {
                error[result.controlName] = undefined;
            });
            return error;
        }
    }
}