import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ComponentsModule } from '../../../components/components.module';
import { CommonserviceProvider } from '../../../providers/commonservice/commonservice';
import { Commonpostsignongatewayservice } from '../../../providers/commonpostsignongatewayservice/commonpostsignongatewayservice';
import { OtvcSetupPage } from './otvcSetup';

@NgModule({
  declarations: [
    OtvcSetupPage,
  ],
  imports: [ComponentsModule,
    IonicPageModule.forChild(OtvcSetupPage),
  ],
  exports: [
    OtvcSetupPage
  ],
  providers: [
    CommonserviceProvider,
    Commonpostsignongatewayservice
  ]
})
export class OtvcSetupPageModule {}  