import { OtvcSetupValidator } from '../otvcValidatorService/OtvcSetupValidator';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { PopupService } from '../../../services/popupService/popupService';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
//import { AnonymousSubject } from 'rxjs';
//import { OtvcValidatorService } from '../../otvcValidatorService/otvcValidatorService';
import { AppErrorHandler } from '../../../services/errorhandler/AppErrorHandler';
//import { BaseTxnPage } from '../../basetxn/basetxn';
import { BasePage } from '../../base/base';
//import { CachedService }from '../../../services/cachedService/cachedService';
import { SessionStorageService } from '../../../services/StorageService/SessionStorageService';
import { RootService } from '../../../services/rootService/root.service';
import { LoadingService } from '../../../services/loadingService/loading.service';
import { isUndefined, isDefined } from 'ionic-angular/util/util';
import { Commonpostsignongatewayservice } from '../../../providers/commonpostsignongatewayservice/commonpostsignongatewayservice';
import { ErrorEventHandlerService } from '../../../services/errorEventHandlerService/ErrorEventHandlerService';
import { Location } from '@angular/common';
import { CookieService } from 'ngx-cookie-service';
import { StateTransitionService } from '../../../services/stateTransition/state.transition.service';
import { PageInitService } from '../../../services/pageInitService/pageInitService';


@IonicPage({ name: 'OtvcSetup', segment: 'otvcSetup' })
@Component({
  selector: 'page-otvcSetup',
  templateUrl: 'otvcSetup.html',
  providers: [AppErrorHandler]
})
export class OtvcSetup extends BasePage {

  isSubmit: boolean;
  pageState: any = {};
  pageContent: any = {};
  completed: boolean;
  modetype: string;
  errorModel: object = {};
  tooltipModal: any;
  skip: any;
  formError: any = {};
  header: string;
  isFormSubmit: boolean;
  lang: string;
  lob: string;
  isWrapper: boolean;
  isIos: boolean;
  headerObj: any;
  footerObj: any;
  PageContentResp: any;
  isDataAvailable: boolean = false;
  hasUnexpectedException: boolean = false;
  unexpectedException: string;
  cachedData: object;
  select: number;
  otvcSetupForm: FormGroup;
  focus: string = "";
  hasError: boolean;
  config = require('../../../providers/commonpostsignongatewayservice/gateway-config.json');
  stateConfig = require('../../../services/stateTransition/state.config.json');
  newdata: any;


  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public modalCtrl: ModalController,
    public cookieService: CookieService,
    public rootService: RootService,
    //public cachedService: CachedService,
    public loadingService: LoadingService,
    public popupService: PopupService,
    public errorHandler: AppErrorHandler,
    public stateTransitionService: StateTransitionService,
    public location: Location,
    public pageInitService: PageInitService,
    public errorEventHandler: ErrorEventHandlerService,
    private formBuilder: FormBuilder
    // public commonGatewayService: Commonpostsignongatewayservice,
    // public otvcRestApiService: OtvcRestApiService
  ) {

    super(navCtrl, location, errorEventHandler, errorHandler, stateTransitionService, pageInitService);
    let root: any = RootService.getRoot();
    if (isUndefined(root)) {
      this.lang = (this.navParams.get('lang') ? this.navParams.get('lang') : (this.cookieService.get('MBI_LANG') ? this.cookieService.get('MBI_LANG') : 'en'));
      this.lob = (this.navParams.get('lob') ? this.navParams.get('lob') : (this.cookieService.get('MBI_LOB') ? this.cookieService.get('MBI_LOB') : 'ie'));
      let root = { 'lob': this.lob, 'lang': this.lang };
      RootService.setRoot(root);
    } else {
      this.lob = root.lob;
      this.lang = root.lang;
    }

    this.headerObj = {
      "mode": 'SignOn', "showlogo": false, "hideBackButton": true,
      'lob': this.lob, 'lang': this.lang
    };
    this.footerObj = { "type": 'SignOn', 'lob': this.lob, 'lang': this.lang };
   
   
  }

  ionViewDidLoad() {    
    this.otvcSetupForm = OtvcSetupValidator.createForm(this.otvcSetupForm, this.formBuilder);
  }

  setPageState(data) {
    this.pageContent = data.PageContentResp.Contents;
    SessionStorageService.clearData('userSigningOn');

    this.isWrapper = RootService.getWrapperObj("isWrapperApp");
    this.setRoot();
    
    this.headerObj.headerContent = this.pageContent.text.pageHeader;
    this.footerObj.content = this.pageContent;
    this.isDataAvailable = true;
    this.hasUnexpectedException = this.navParams.get('unexpectedException');
    if (this.hasUnexpectedException) {
      this.unexpectedException = this.pageContent.error.unexpectedException;
    }


  }
  setRoot() {
    let root: any = RootService.getRoot();
    if (isUndefined(root)) {
      root = SessionStorageService.getData("root");
    }
    this.lang = root.lob;
    this.lob = root.lang;

  }
  createRequest() {
    RootService.setPageName("OtvcSetup");
    return { "RetrieveOtvcReq": {}, "PageContentReq": { "PageName": "Security" } }
  }

  onSetup(value: any) {
    this.pageState = {
      "MOBILE_PHONE": "",
      "HOME_PHONE": "",
      "BUSINESS_PHONE": "",
      "EMAIL": "",
      "alwaysOtvc":""
    };
    OtvcSetupValidator.setValidators(this.otvcSetupForm, this.formBuilder);
    OtvcSetupValidator.setValue(this.otvcSetupForm);
    this.loadingService.present();

    if (this.otvcSetupForm.valid) {
      // prepare OtvcDetail
      let otvcContacts = [];
      if (isDefined(this.pageState.MOBILE_PHONE)) {
        otvcContacts.push({ Method: "MOBILE_PHONE", Value: this.pageState.MOBILE_PHONE });
      }

      if (isDefined(this.pageState.HOME_PHONE)) {
        otvcContacts.push({ Method: "HOME_PHONE", Value: this.pageState.HOME_PHONE });
      }

      if (isDefined(this.pageState.BUSINESS_PHONE)) {
        otvcContacts.push({ Method: "BUSINESS_PHONE", Value: this.pageState.BUSINESS_PHONE });
      }

      if (isDefined(this.pageState.EMAIL)) {
        otvcContacts.push({ Method: "EMAIL", Value: this.pageState.EMAIL });
      }

      var req: any = { "OtvcContact": otvcContacts };
      if (this.pageState.alwaysOtvc) {
        req.alwaysOtvc = this.pageState.alwaysOtvc;
      }

      // add to cache
      SessionStorageService.setData('otvcSetupCache', req);

      // navigate
      SessionStorageService.setData('userSignedOn', true);
      RootService.setPageName("OtvcVerify");
      this.navCtrl.push("OtvcVerify", { "lob": this.lob, "lang": this.lang }, { animate: false });
    } else {
      //show validations
      this.formError = OtvcSetupValidator.resolveValidationError(this.otvcSetupForm, this.pageContent.error);
      this.focus = "error";
      console.log('Form Error --- ' + JSON.stringify(this.formError));
      if (this.hasError) {
        super.clearError();
      }
    }
  }


  resetFormError() {
    let controlName = this.otvcSetupForm; // If no parameter passed, whole Form will be reseted.
    if (arguments.length > 0) { // If any parameter passed, that particular controlName will be reseted.
      controlName = arguments[0];
      this.formError[arguments[0]] = OtvcSetupValidator.resetErrorMessage(controlName);
    } else {
      this.formError = OtvcSetupValidator.resetErrorMessage(controlName);
    }
  }


  ///     
  /* req = {
     "PageContentReq": { "PageName": "Security" },
     "RetrieveOtvcReq": {}
 }*/

  /* let APIServices = this.config.APIServices;
      let response = {};
      this.loadingService.present();
      this.commonpostsignongatewayservice.init(request,APIServices["otvcInit"].url).subscribe((data: any) => {
				if (data) {
          this.zeroOrders = data.SearchInfo.TotalNumberOfResult == 0;
          response = { "FilterType": this.selectedFilter, "Data": data };
          if (!this.zeroOrders) {
            this.viewCtrl.dismiss(response);
          }
				} else {
					
				}
				this.loadingService.dismiss();
			},
				(err: HttpErrorResponse) => {
					this.hasError = true;
					super.handleError(err);
					this.loadingService.dismiss();
				});   
    }

    this.otvcGatewayService.init().then(
  }
     */

  /* 
    ionViewDidLoad() {
       this.lang = this.rootService.getLang();
       this.lob = this.rootService.getLOB(); 
    }*/



  /*setPageState(data) {
    SessionStorageService.clearData('userSigningOn');
    console.log(JSON.stringify(data));
  }*/
  continue() {
    SessionStorageService.setData('userSignedOn', true);
    RootService.setPageName("OtvcVerify");
    this.navCtrl.push("OtvcVerify", { "lob": this.lob, "lang": this.lang }, { animate: false });
  }


  setInitData(data) {
    this.modetype = 'preTxn';
    if (isDefined(data)) {
      this.skip = data.RetrieveOtvcResp.Skip;
      this.otvcPageState(data.RetrieveOtvcResp, data.PageContentResp.Contents);
      // if (isUndefined(otvcsetupCache.get('confirmData'))) {
      //     this.confirmChange();
      // }
    }
  }

  otvcPageState(otvcDetails, pageContent) {
    this.pageContent = pageContent;
    this.pageState = {
      "MOBILE_PHONE": "",
      "HOME_PHONE": "",
      "BUSINESS_PHONE": "",
      "EMAIL": "",
      "alwaysOtvc":""
    };
    //this.formValidationMessages = this.setUpFormValidationMessages(pageContent);
    // this.pageState = this.otvcValidator.populateErrorModel(this.pageState);
    // this.header = this.isUserLogIn() ? pageContent.text.pageHeader1 : pageContent.text.pageHeader2;
    // if (isDefined(otvcDetails.OtvcDetail)) {
    //   this.pageState.alwaysOtvc = otvcDetails.OtvcDetail.AlwaysOtvc;
    //   var contacts = otvcDetails.OtvcDetail.Contact;
    //   contacts.forEach(obj => {
    //     if (obj.Method != 'MOBILE_PHONE_TEXT') {
    //       this.pageState[obj.Method] = obj.Method != 'EMAIL' ? this.toViewFormat(obj.Value) : obj.Value;
    //     }
    //   })
    // }
    this.tooltipModal = this.modalCtrl.create(pageContent, this.header);
    // this.validateSubmit();
  }
  /*
    confirmChange() {
        this.loadingService.dismiss();
        let alertContent = {
            title: "",
            subTitletitle: "",
            message: this.pageContent.text.completed,
            buttons: this.pageContent.text.okButton,
            onPresent: () => {
                var otvcsetupCache = this.cibcCache.getCache('otvcsetupCache');
                otvcsetupCache.remove('confirmData');
            }
        };
        this.popupService.presentAlert(alertContent);
    }*/
  toViewFormat(modelPhone) {
    modelPhone = modelPhone || "";
    modelPhone = modelPhone.replace(/[^0-9]/g, '');
    this.validateSubmit();
    if (modelPhone) {
      // $scope.isSubmit = isDefined($scope.pageState.EMAIL.value)?validateEmail($scope.pageState.EMAIL.value):true;  
      //e.g. 416
      if (modelPhone.length <= 3) {
        return modelPhone;
      }
      //e.g. 416581
      if (modelPhone.length <= 6) {
        let area = modelPhone.substr(0, 3);
        let num1 = modelPhone.substr(3);
        return `${area} ${num1}`;
      }
      //e.g. 14165817080
      let area = modelPhone.substr(0, 3);
      let num1 = modelPhone.substr(3, 3);
      let num2 = modelPhone.substr(6);
      return `(${area}) ${num1} ${num2}`;
    }
    this.pageState.MOBILE_PHONE = modelPhone;
    return modelPhone;
  }

  validateSubmit() {
    var validPhone = (isDefined(this.pageState.HOME_PHONE) || isDefined(this.pageState.MOBILE_PHONE) || isDefined(this.pageState.BUSINESS_PHONE));
    if (isDefined(this.pageState.EMAIL) && this.pageState.EMAIL != "") {
      this.isSubmit = this.validateEmail(this.pageState.EMAIL) && validPhone;
    } else {
      this.isSubmit = validPhone;
    }
  }
  validateEmail(email) {
    let passWhitelist = false;
    let INVERSE_WHITELIST = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if (isDefined(email) && email != "") {
      passWhitelist = !(email.match(INVERSE_WHITELIST) === null);
      this.isSubmit = passWhitelist;
      return passWhitelist;
    } else {
      this.isSubmit = (isDefined(this.pageState.HOME_PHONE) || isDefined(this.pageState.MOBILE_PHONE) || isDefined(this.pageState.BUSINESS_PHONE));
      return this.isSubmit;
    }

  }
  openEmailInfo() {
    this.tooltipModal.openModal();
  }
  /*
    isUserLogIn() {
        var restoredValue = this.cibcStorage.getObject(
            this.cibcStorage.sessionStorage,
            this.cibcStorage.cookieStorage,
            'userSignedOn');
        var userSignedOn = restoredValue;
        if (!isDefined(userSignedOn)) {
            userSignedOn = false;
        }
        return userSignedOn;
    }
  
    
  
    transactionInit(payload) {
        let endpoint = this.config.appRestBaseUrl + this.config.cibcOtvcSetupConfig.serviceRootURL +
            this.config.cibcOtvcSetupConfig.serviceURLs.initURL;
  
        return this.otvcRestApiService.init(endpoint, payload);
    }
    transactionValidate(obj) {
        var endpoint = this.config.appRestBaseUrl + this.config.cibcOtvcSetupConfig.serviceRootURL +
          this.config.cibcOtvcSetupConfig.serviceURLs.validateURL;
    
        var payload = {
          ValidateOtvcDetailReq: obj,
          PageContentReq: { "PageName": "IdentityVerification" }
        };
    
        return this.otvcRestApiService.validate(endpoint, payload);
      }
    
      transactionSetUserLogIn() {
        if (!this.isUserLogIn()) {
          this.cibcStorage.setObject(
            this.cibcStorage.sessionStorage,
            this.cibcStorage.cookieStorage,
            'userSignedOn', true);
        }
      }
    
      transactionSkip() {
        var endpoint = this.config.appRestBaseUrl + this.config.cibcOtvcSetupConfig.serviceRootURL +
          this.config.cibcOtvcSetupConfig.serviceURLs.serviceOTVCSkipURL;
        var payload = {};
        return this.otvcRestApiService.skip(endpoint, payload);
      }
    
      /*Gateway service methods*/
  gatewayInit(mode) {
    // CibcStorage.setObject(
    //     CibcStorage.sessionStorage,
    //     CibcStorage.cookieStorage,
    //     'userSignedOn', true);
    return new Promise((resolve, reject) => {
      let req = {
        "PageContentReq": { "PageName": "Security" },
        "RetrieveOtvcReq": {}
      }
      // this.transactionInit(req).subscribe(function (result) {
      //   var otvcsetupCache = SessionStorageService.getData('otvcsetupCache');
      //   otvcsetupCache.put('initData', result.data);
      //   otvcsetupCache.put('mode', mode);
      //   this.canProceed = true;
      //   if (mode == 'preTxn') {
      //     this.nextState = 'preTxn.OTVCSETUP';
      //   } else {
      //     if (mode == 'DEFAULT') {
      //       otvcsetupCache.put('confirmData', true);
      //     }
      //     this.nextState = 'txn.OTVCSETUP'
      //   }
      //   resolve(result);
      // }, function (result) {
      //   reject(result);
      // });
    });
  }

  gatewayValidate(req) {
    // return new Promise((resolve, reject) => {
    //   this.transactionValidate(req).subscribe(
    //     function (result) {
    //       //success callback
    //       var otvcsetupCache = SessionStorageService.getData('otvcsetupCache');
    //       otvcsetupCache.put('otvcData', result.data);
    //       this.transactionSetUserLogIn();
    //       resolve(result);
    //     },
    //     function (result) {
    //       //error callback
    //       var otvcCache = SessionStorageService.getData('otvcsetupCache');
    //       // _canProceed=true;
    //       otvcCache.put('errorData', result.data);
    //       // _nextState = 'preTxn.signOn';
    //       reject(result);
    //     }
    //   );
    // });
  }


  /*  gatewaySkip(code) {
     return new Promise((resolve, reject) => {
       this.transactionSkip().subscribe(
         function (result) {
           //success callback
           var otvcCache = SessionStorageService.getData('otvcsetupCache');
           otvcCache.put('verifyOTVCData', result.data);
           this.canProceed = true;
           this.nextState = 'MyAccounts';
           resolve(result);
         },
         function (result) {
           //error callback
           var otvcCache = SessionStorageService.getData('otvcsetupCache');
           // _canProceed=true;
           otvcCache.put('errorData', result.data);
           // _nextState = 'preTxn.signOn';
           reject(result);
         }
       );
     });
   }  */
}



