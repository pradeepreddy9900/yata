import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ComponentsModule } from '../../../components/components.module';
import { CommonserviceProvider } from '../../../providers/commonservice/commonservice';
import { Commonpostsignongatewayservice } from '../../../providers/commonpostsignongatewayservice/commonpostsignongatewayservice';
import { OtvcSetup } from './otvcSetup';

@NgModule({
  declarations: [
    OtvcSetup,
  ],
  imports: [ComponentsModule,
    IonicPageModule.forChild(OtvcSetup),
  ],
  exports: [
    OtvcSetup
  ],
  providers: [
    CommonserviceProvider,
    Commonpostsignongatewayservice
  ]
})
export class OtvcSetupPageModule {}  